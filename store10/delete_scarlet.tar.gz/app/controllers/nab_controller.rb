class NabController < ApplicationController
  layout 'static_pages'

  def index
    epic
    render 'nab/epic'
    @page_title = "RED / EPIC"
    
  end

  def epic
    @page_title = "RED / EPIC"
  end
  def red_ray
    @page_title = "RED / RED RAY"
  end

  def lenses
    @page_title = "RED / LENSES"
  end
end
