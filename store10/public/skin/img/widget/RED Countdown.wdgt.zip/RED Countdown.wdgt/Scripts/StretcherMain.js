
var stretcher;
var xml_request = null;
var url = "http://beta.red.com/news/rss/"; 

//"http://red.com/news/wp-rss2.php"; 
//"http://www.hi-leeon.com/rednews.xml"; 
//"http://red.com/news/rss/";

var last_updated = 0;                                // Track last refresh time to avoid excessive

var scrollbar, scrollArea;

if (window.widget){
	widget.onshow = loaded;
	widget.onhide = reSizeFun;
}

function reSizeFun(){
	if(stretcher.isStretched()){
		stretcher.stretch(event);
	}
	clearInterval(countDownID);
	countDownID = null;
	document.getElementById("MsecImg").innerHTML = "";

}
function initScrollBar(){
	scrollbar = new AppleVerticalScrollbar(document.getElementById("myScrollBar"));
	scrollArea = new AppleScrollArea(document.getElementById("center"), scrollbar);
	scrollArea.scrollsHorizontally = false;
	scrollArea.singlepressScrollPixels = 25;
	scrollArea.focus(); // for key control when first loading in Safari
	window.onfocus = function () { scrollArea.focus(); }
	window.onblur = function () { scrollArea.blur(); }
	//scrollArea.reveal(newContent);
	scrollArea.refresh();
}

// Kicks everything off.  
function loaded () {
	if(!window.widget)
	{
		show();
	}
}

function handleResponse(){
	if(xml_request.readyState == 4){
	
		if(xml_request.status == 200){
		
			
			document.getElementById("ctrContent").innerHTML = "";
			var myXML = xml_request.responseXML;
			//alert( xml_request.responseText);
			var items = myXML.getElementsByTagName('item');
			
			var table = document.createElement("table")
			table.setAttribute("border","0");
			table.setAttribute("style","width:100%;");
			
			for(var i=0;i<items.length;i++){
				
				var linkStr = (items[i].getElementsByTagName("link")[0].firstChild.nodeValue);
				
				var titleStr = (items[i].getElementsByTagName("title")[0].firstChild.nodeValue);

				var desc = items[i].getElementsByTagName("description")[0];

				

				if(desc.getElementsByTagName("p")[0] != null){			
					var contStr = (desc.getElementsByTagName("p")[0].firstChild.nodeValue.replace("\r\n"," "));
				}else{
					var contStr = "&nbsp;"
				}
				
				if(desc.getElementsByTagName("img")[0] != null){							
					var imgStr = (desc.getElementsByTagName("img")[0].src);
				}

				var widthNum = 66;
				var heightNum = 66;
				
				var tr = document.createElement("tr");
				var td = document.createElement("td");
				td.setAttribute("colspan","2")

				//<a href='javascript:openIt(\""+linkStr+"\")' target='_blank' style='color:#FFFFFF'>;
				td.innerHTML = "<a href='javascript:openIt(\""+linkStr+"\")' target='_blank' style='color:#FFFFFF'>"+ titleStr+"</a>";
				
				
				tr.appendChild(td);
				table.appendChild(tr);
				var tr = document.createElement("tr");
				var td = document.createElement("td");
				var img =  document.createElement("img");
				
				img.setAttribute("src",imgStr);
				img.setAttribute("width",widthNum);
				img.setAttribute("height",heightNum);

				td.width = widthNum;
				td.height = heightNum;
				td.appendChild(img);
				tr.appendChild(td);
				
				var td = document.createElement("td");
				td.align = "left";
				td.setAttribute("style","vertical-align:top");
				td.height = heightNum;
				td.innerHTML = "";
				td.innerHTML = contStr;
				
				tr.appendChild(td);
				table.appendChild(tr);
				
			}
			
			document.getElementById("ctrContent").appendChild(table);
			//alert(document.getElementById("ctrContent").innerHTML);
			last_updated = (new Date).getTime();
			
			document.getElementById("logo").innerHTML = "<a href='javascript:stretcher.stretch(event);'><img src='Images/logo.png'></a>";
			document.getElementById("news").innerHTML = "<a href='javascript:stretcher.stretch(event);'><img src='Images/news.png'/></a>";
			
		}else{
			if(xml_request.status==404){
				document.getElementById("ctrContent").innerHTML = "<p align='center'>Error 404, RSS can not be found.</p>";
			}else{
				if(xml_request.status == undefined){
					document.getElementById("ctrContent").innerHTML = "<p align='center'>Error, Server unavailable </p>";	
				}else{
					document.getElementById("ctrContent").innerHTML = "<p align='center'>Error "+xml_request.status+"</p>";
				}
			}
		}
	}
}

function countDown(){
		// TargetDate = "10/31/2006 11:59:59 PM UTC-0800";
	// "2007/04/14 01:00:00 PM UTC-0700";
	//	var newD = new Date(Date.UTC(2007,3,14,13,0,0,0))//("2007/04/14 13:00:00");
	var newD = new Date("2007/04/14 01:00:00 PM UTC-0700");
	
	var nowD = new Date();
	if((newD - nowD)>0){
			var leftD = newD.getTime() - nowD.getTime();
			/* Days */
			var leftDay = Math.floor(leftD/1000/60/60/24);
			var img = "";
			for(var i=0;i<String(leftDay).length;i++){
				img += "<img src='images/" +  String(leftDay).substring(i,i+1) + ".png'/>";
			}
			document.getElementById("dayImg").innerHTML = img;
			/* Hours */ 
			var leftHour = (leftD/1000/60/60/24) - leftDay;
			var img = "";
			
			if(Number(Math.floor(leftHour*24)) <10){
				img = "<img src='images/0.png'/><img src='images/" + String(Math.floor(leftHour*24)) + ".png'/>";
			}else{
				for(var i=0;i<String(Math.floor(leftHour*24)).length;i++){
					img += "<img src='images/" + String(Math.floor(leftHour*24)).substring(i,i+1) + ".png'/>";
				}
			}
			document.getElementById("hourImg").innerHTML = img;	
			/* Mins */
			var leftMin = leftHour*24 - Math.floor(leftHour*24)
			var mins =Math.floor((leftHour*24-Math.floor(leftHour*24))*60);	
			var img = "";
			
			if(Number(mins) <10){
				img = "<img src='images/0.png'/><img src='images/" + String(mins) + ".png'/>";
			}else{
				for(var i=0;i<String(mins).length;i++){
					img += "<img src='images/" + String(mins).substring(i,i+1) + ".png'/>";
				}
			}
			document.getElementById("minImg").innerHTML = img;	
			
			/* Secs */
			var leftSec = leftMin*60 - mins;
			var sec = Math.floor(leftSec*60);
			var img = "";
			if(Number(sec)<10){
				img = "<img src='images/0.png'/><img src='images/" + String(sec) + ".png'/>";	
			}else{
				for(var i=0;i<String(sec).length;i++){
					img += "<img src='images/" + String(sec).substring(i,i+1) + ".png'/>";
				}
			}
			document.getElementById("secImg").innerHTML = img;	
			
			// Msec 
			//	var leftMsec = leftSec*60 - sec;
			//	var Msec = Math.floor(Math.floor(leftMsec*1000)/100)
			//	var img = "";
			
			//	if(Number(Msec)<10){
			//	img = "<img src='images/0.png'/><img src='images/" + String(Msec) + ".png'/>"
			//	}else{
			//		for(var i=0;i<String(Msec).length;i++){
			//		img += "<img src='images/" + String(Msec).substring(i,i+1) + ".png'/>";
			//		}
			//	}
			
	}else{
			document.getElementById("dayImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
			document.getElementById("hourImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
			document.getElementById("minImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
			document.getElementById("secImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
			document.getElementById("MsecImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
			clearInterval(countDownID);
	}
}

// Kicks everything off.  
function loaded () {
	
	
	stretcher = new Stretcher(document.getElementById('front'), 100, 348, checkScroll);
	
	document.getElementById("dayImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
	document.getElementById("hourImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
	document.getElementById("minImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
	document.getElementById("secImg").innerHTML = "<img src='images/0.png'><img src='images/0.png'>";
	document.getElementById("MsecImg").innerHTML = "<img src='Images/digital.gif'>";
	
	
	countDownID = setInterval(countDown,1000);
	
	
	var now = (new Date).getTime();
	
	// only check if 15 minutes have passed
	if ((now - last_updated) > 900000) {
	//if((now - last_updated)>10){
			if(xml_request != null){
				xml_request.abort();
				xml_request = null;
			}
			
			if(window.XMLHttpRequest){
				xml_request = new XMLHttpRequest();
			}else if(window.ActiveXObject){
				xml_request = new ActiveXObject("Msxl2.XMLHTTP");
				if(!xml_request){
					xml_request = new ActiveXObject("Microsoft.XMLHTTP");
				}	
			}
			xml_request.onreadystatechange = handleResponse ;		
			xml_request.overrideMimeType('text/xml');
			
			//alert(url);
			xml_request.open("GET",url);
			xml_request.setRequestHeader("Cache-Control", "no-cache");
			xml_request.send(null);
	}
}

function checkScroll () {
	if(stretcher.isStretched()){
		document.getElementById('myScrollBar').style.display = 'block';
	}
	initScrollBar();
}

function openIt(param_url){
	if(window.widget){
		widget.openURL(param_url);
		reSizeFun();
	}else{
		 document.location = param_url;
	}
}

/*** Applc animation ***/

var flipShown = false;		

function showPrefs(){
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget){
		widget.prepareForTransition("ToBack");		// freezes the widget so that you can change it without the user noticing
	}
	
	front.style.display="none";		// hide the front
	back.style.display="block";		// show the back
	
	if (window.widget){
		setTimeout ('widget.performTransition();', 0);		// and flip the widget over	
	}
	document.getElementById('fliprollie').style.display = 'none';  // clean up the front side - hide the circle behind the info button
}

function hidePrefs(){
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget){
		widget.prepareForTransition("ToFront");		// freezes the widget and prepares it for the flip back to the front
	}
	
	back.style.display="none";			// hide the back
	front.style.display="block";		// show the front
	
	if (window.widget){
		setTimeout ('widget.performTransition();', 0);							// and flip the widget back to the front
	}
}

var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};

function mousemove (event)
{
	if (!flipShown)																					// if the preferences flipper is not already showing...
	{
		if (animation.timer != null)															// reset the animation timer value, in case a value was left behind
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		var starttime = (new Date).getTime() - 13; 								// set it back one frame		
		animation.duration = 500;															// animation time, in ms
		animation.starttime = starttime;													// specify the start time
		animation.firstElement = document.getElementById ('flip');		// specify the element to fade
		animation.timer = setInterval ("animate();", 13);							// set the animation function
		animation.from = animation.now;													// beginning opacity (not ness. 0)
		animation.to = 1.0;																		// final opacity
		animate();																					// begin animation
		flipShown = true;																		// mark the flipper as animated
	}
}

function mouseexit (event){
	if (flipShown){
		// fade in the flip widget
		if (animation.timer != null){
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		var starttime = (new Date).getTime() - 13;		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}

// animate() performs the fade animation for the preferences flipper. It uses the opacity CSS property to simulate a fade.
function animate(){
	var T;
	var ease;
	var time = (new Date).getTime();
	T = limit_3(time-animation.starttime, 0, animation.duration);	
	if (T >= animation.duration){
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}else{
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	animation.firstElement.style.opacity = animation.now;
}
// these functions are utilities used by animate()
function limit_3 (a, b, c){
    return a < b ? b : (a > c ? c : a);
}
function computeNextFloat (from, to, ease){
    return from + (to - from) * ease;
}
// these functions are called when the info button itself receives onmouseover and onmouseout events
function enterflip(event){
	document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event){
	document.getElementById('fliprollie').style.display = 'none';
}

