/*

File: Stretcher.js

*/ 

/*
 ***************************************************************
 * <Stretcher object definition.  Stretches a div up and down> *
 ***************************************************************
 */

/*
 * Stretcher constructor; parameters:
 *
 * -- element: The element to stretch
 * -- stretchDistance: Distance (in pixels) the content should stretch
 * -- stretchDuration: How long (in ms) the stretch animation should take
 * -- onFinished: A callback (if no callback is needed, pass null)
 *
 */
function Stretcher (element, stretchDistance, stretchDuration, onFinished) {
	this.element = element;	
	this.stretchDistance = stretchDistance;
	this.duration = stretchDuration;
	this.onFinished = onFinished;

	this.multiplier = 1;	
	
	// min and max position can be changed to alter the stretched/shrunk sizes;
	// getComputedStyle depends on the target (in this case, the stretcher element)
	// being visible, so don't instantiate the Stretcher until the content is shown
	this.minPosition = parseInt(document.defaultView.getComputedStyle(this.element, "").getPropertyValue("height"));
	this.maxPosition = this.minPosition + this.stretchDistance;
	
	// Set variables to what they'd be in the beginning "shrunk" state
	this.positionFrom = this.minPosition;
	this.positionTo = this.maxPosition;
		
	// new AppleClasses support
	var self = this; // eliminates scope problems in timers/event handlers
	
	this.stretchAnimator = null;
			
	// AppleAnimation callback; this is where we actually change the size
	this.nextFrame = function (animation, now, first, done) {
		self.element.style.height = now + "px";
	}
	
	this.changeDirection = function () {
		if (self.positionTo == self.maxPosition) {
			self.positionTo = self.minPosition;
		} else {
			self.positionTo = self.maxPosition;
		}
	}
	
	// Callback for AppleAnimator; also called to interrupt a stretch-in-progress
	this.doneStretching = function () {
		// If we've just shrunk, resize the window to the new AFTER the animation is complete
		if (window.widget && (parseInt(self.element.style.height) == self.minPosition)) {
			window.resizeTo(parseInt(document.defaultView.getComputedStyle(self.element, "").getPropertyValue("width")), self.minPosition);
		}
		self.positionFrom = parseInt(self.element.style.height);
		self.changeDirection();
		delete self.stretchAnimator;
		if (self.onFinished) {
			self.onFinished();
		}
	}
}

/*
 * This should only be called via a Stretcher instance, i.e. "instance.stretch(event)"
 * Calling Stretcher_stretch() directly will result in "this" evaluating to the window
 * object, and the function will fail; parameters:
 * 
 * -- event: the mouse click that starts everything off (from an onclick handler)
 *		We check for the shift key to do a slo-mo stretch
 */
Stretcher.prototype.stretch = function (event) {
	document.getElementById('myScrollBar').style.display = 'none'; 
	if (event && event != undefined && event.shiftKey) {
		// enable slo-mo
		this.multiplier = 10;
	} else this.multiplier = 1;
	
	// if we're currently stretching
	if (this.stretchAnimator) {
		this.stretchAnimator.stop();
		var handler = this.onFinished;
		this.onFinished = null;
		this.doneStretching();
		this.onFinished = handler;
	} 
	
	// Resize the window before stretching to make room for the newly-sized content
	if (window.widget && (this.positionTo == this.maxPosition)) {
		window.resizeTo(parseInt(document.defaultView.getComputedStyle(this.element, "").getPropertyValue("width")), this.positionTo);
	}
	this.stretchAnimator = new AppleAnimator(this.duration * this.multiplier, 13, this.positionFrom, this.positionTo, this.nextFrame);
	this.stretchAnimator.oncomplete = this.doneStretching;
	this.stretchAnimator.start();
}
	

/*
 * Report whether or not the Stretcher is in its maximized position
 * DO NOT call this function to determine whether or not the Stretcher is 
 * currently animating; set the onFinished handler to be notified when animation
 * is complete
 */
Stretcher.prototype.isStretched = function() {
	return (parseInt(this.element.style.height) == this.maxPosition);
}

/*
 ************************************************************************
 * Debug code uses the div defined in Scroller.html/Scroller.css demo	*
 ************************************************************************
 */
var debugMode = false;

// write to the debug div
function DEBUG(str) {
	if (debugMode) {
		if (window.widget) {
			alert(str);
		} else {
			var debugDiv = document.getElementById("debugDiv");
			debugDiv.appendChild(document.createTextNode(str));
			debugDiv.appendChild(document.createElement("br"));
			debugDiv.scrollTop = debugDiv.scrollHeight;		
		}
	}
}

// Toggle the debugMode flag, but only show the debugDiv if we're in Safari
function toggleDebug() {
	debugMode = !debugMode;
	if (debugMode == true && !window.widget) {
		document.getElementById("debugDiv").style.display = "block";
	} else {
		document.getElementById("debugDiv").style.display = "none";
	}
}