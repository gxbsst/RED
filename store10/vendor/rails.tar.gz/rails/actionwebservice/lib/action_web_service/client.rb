require 'action_web_service/client/base'
require 'action_web_service/client/soap_client'
require 'action_web_service/client/xmlrpc_client'
