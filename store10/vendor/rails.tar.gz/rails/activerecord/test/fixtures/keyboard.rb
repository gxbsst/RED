class Keyboard < ActiveRecord::Base
  set_primary_key 'key_number'
end
