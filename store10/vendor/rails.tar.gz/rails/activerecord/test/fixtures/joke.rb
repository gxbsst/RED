class Joke < ActiveRecord::Base
  set_table_name 'funny_jokes'
end
class Joke < ActiveRecord::Base
  set_table_name 'funny_jokes'
end