# see routing/controller component tests

raise Exception, "I should never be loaded"