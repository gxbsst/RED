class AClassThatContainsAController::PoorlyPlacedController < ActionController::Base
  
  def self.is_evil?
    :decidedly_so
  end
  
end