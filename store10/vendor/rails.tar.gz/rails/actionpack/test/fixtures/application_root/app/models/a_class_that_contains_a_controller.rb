class AClassThatContainsAController #often < ActiveRecord::Base
  
  def self.is_special?
    :you_know_it
  end
  
end