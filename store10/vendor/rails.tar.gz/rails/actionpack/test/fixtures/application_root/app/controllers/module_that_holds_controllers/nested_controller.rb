class ModuleThatHoldsControllers::NestedController < ActionController::Base
  
end