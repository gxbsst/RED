require File.dirname(__FILE__) + '/object/extending'
require File.dirname(__FILE__) + '/object/misc'