require File.dirname(__FILE__) + '/class/attribute_accessors'
require File.dirname(__FILE__) + '/class/inheritable_attributes'
require File.dirname(__FILE__) + '/class/removal'